import json
import pickle
import csv
import random
# from googletrans import Translator

from google_trans_new import google_translator
translator = google_translator()  

with open('QAtracker.csv') as file_data:
    print(file_data)
    csv_reader = csv.reader(file_data, delimiter=',')
    line_count = 0
    # data_dict = {}
    data = {}
    data['intents'] = []
    
    for row in csv_reader:
        #for english
        trans_result=translator.translate(row[5],lang_tgt="en")
        print(trans_result)
        #this is for more then one string
        if ' ' in row[5]:
            print(type(row[5]))
            print(row[5].split())
            print(row[5].split()[0])
            trans_result1=translator.translate(row[5].split()[0],lang_tgt="en")
            print("trans_result1 is:",trans_result1.lower().strip())
            print(row[5].split()[1])
            trans_result2=translator.translate(row[5].split()[1],lang_tgt="en")
            print("trans_result2 is:",trans_result2.lower().strip())
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring': [trans_result1.lower().strip()]
            })
            line_count += 1;
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring': [trans_result2.lower().strip()]
            })
        else:
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring':[trans_result.lower().strip()]
            })
        line_count += 1;
        
with open('QAtracker.csv') as file_data:
    print(file_data)
    csv_reader = csv.reader(file_data, delimiter=',')
    for row in csv_reader:
        #for German
        trans_result=translator.translate(row[5],lang_tgt="de")
        print(trans_result)
        #this is for more then one string
        if ' ' in row[5]:
            print(type(row[5]))
            print(row[5].split())
            print(row[5].split()[0])
            
            #for German or english(use de for german)
            trans_result1=translator.translate(row[5].split()[0],lang_tgt="de")
            print("trans_result1 is:",trans_result1.lower().strip())
            print(row[5].split()[1])
            trans_result2=translator.translate(row[5].split()[1],lang_tgt="de")
            print("trans_result2 is:",trans_result2.lower().strip())
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring': [trans_result1.lower().strip()]
            })
            line_count += 1;
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring': [trans_result2.lower().strip()]
            })
        else:
            data['intents'].append({
            'id': line_count,
            'url': [row[4]],
            'searchstring':[trans_result.lower().strip()]
            })
        line_count += 1;

print("all data in english :",data)

with open('Alldata.json', 'w' ,encoding='UTF8') as outfile:
    json.dump(data, outfile)